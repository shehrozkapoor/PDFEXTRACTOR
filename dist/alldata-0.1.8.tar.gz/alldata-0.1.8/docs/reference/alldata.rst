alldata
=======

.. testsetup::

    from alldata import *

.. automodule:: alldata
    :members:
