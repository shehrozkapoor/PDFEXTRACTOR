
Changelog
=========

0.0.0 (2020-12-13)
------------------

* First release on PyPI.
